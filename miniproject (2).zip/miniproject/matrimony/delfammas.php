<?php
include('DatabaseCon.php');
$db=new DatabaseCon();

$=$_GET[''];
$sql="delete from tbl_fammas where"
$db->insertQuery($sql);
echo "<script>alert('success')</script>";
?>